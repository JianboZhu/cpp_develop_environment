#include "common/common.h"
#include <iostream>

void Common()
{
    std::cout << "Common" << "\n";
}
