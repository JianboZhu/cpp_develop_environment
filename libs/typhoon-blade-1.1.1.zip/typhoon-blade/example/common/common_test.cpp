#include "common/common.h"
#include <gtest/gtest.h>

TEST(Common, Test)
{
    Common();
}
